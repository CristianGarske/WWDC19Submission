import PlaygroundSupport
import UIKit
import SpriteKit

let gameViewController = GameViewController()
PlaygroundPage.current.liveView = gameViewController
