import SpriteKit
import UIKit
import AVFoundation

public class GameScene: SKScene {
    
    private var character = SKSpriteNode()
    private var characterWalkingFrames: [SKTexture] = []
    
    private var piece = SKSpriteNode()
    private var pieceFloatingFrames: [SKTexture] = []
    
    private var cars = SKSpriteNode()
    private var carsWalkingFrames: [SKTexture] = []
    
    private var carsTop = SKSpriteNode()
    
    private var cameraNode = SKCameraNode()
    
    var dialogueBox = SKShapeNode(rect: CGRect(x: -500, y: 0, width: 0, height: 0))
    
    var dialogueCount = 1
    
    var player: AVAudioPlayer?
    var feedbackPlayer: AVAudioPlayer?
    
    let crossingPiece = SKSpriteNode(imageNamed: "Crossing_Off.png")
    let crossingPiece2 = SKSpriteNode(imageNamed: "Crossing_Off_2.png")
    let stairs = SKSpriteNode(imageNamed: "Stairs.png")
    
    var isTouchActivated = true
    
    let credits = SKSpriteNode(imageNamed: "Credits.png")
    
    override public func didMove(to view: SKView) {
        play("ES_Challenges Ahead - From Now On")
        
        // - Background Configuration
        let plano1 = SKSpriteNode(imageNamed: "Plano1.png")
        plano1.position = CGPoint(x: size.width/2, y: size.height/2+80)
        plano1.zPosition = -3
        
        let plano2 = SKSpriteNode(imageNamed: "Plano2.png")
        plano2.position = CGPoint(x: size.width/2, y: size.height/2+80)
        plano2.zPosition = -5
        
        let plano3 = SKSpriteNode(imageNamed: "Plano3.png")
        plano3.position = CGPoint(x: size.width/2, y: size.height/2+80)
        plano3.zPosition = -9
        
        let plano4 = SKSpriteNode(imageNamed: "Plano4.png")
        plano4.position = CGPoint(x: size.width/2, y: size.height/2+80)
        plano4.zPosition = -12
        
        let plano5 = SKSpriteNode(imageNamed: "Plano5.png")
        plano5.position = CGPoint(x: size.width/2, y: size.height/2+80)
        plano5.zPosition = -14
        
        crossingPiece.position = CGPoint(x: 515, y: 359)
        crossingPiece.zPosition = -7
        
        crossingPiece2.position = CGPoint(x: 713, y: 840)
        crossingPiece2.zPosition = -11
        
        stairs.position = CGPoint(x: 872, y: 565)
        stairs.zPosition = -6
        
        // - Configuring the camera
        cameraNode.xScale = 0.25
        cameraNode.yScale = 0.25
        cameraNode.zPosition = -2
        scene?.camera = cameraNode
        
        // - View Configuration
        backgroundColor = .white
        
        // - Building Background
        addChild(plano1)
        addChild(plano2)
        addChild(plano3)
        addChild(plano4)
        addChild(plano5)
        addChild(crossingPiece)
        addChild(crossingPiece2)
        addChild(stairs)
        
        // - Building Character
        buildCharacter()
        buildDialogeBox()
        buildCars()
        animateCars()
        buildTopCars()
        animateTopCars()
        
        carsTop.zPosition = -10
        cars.zPosition = -6
    }
    
    
    // - Character Building
    func buildCharacter() {
        character.zPosition = 10
        var walkFrames: [SKTexture] = []
        for i in 1...8 {
            let characterTextureName = "character\(i)"
            let character = SKTexture(imageNamed: characterTextureName)
            walkFrames.append(character)
        }
        characterWalkingFrames = walkFrames
        let firstFrameTexture = characterWalkingFrames[0]
        character = SKSpriteNode(texture: firstFrameTexture)
        character.position = CGPoint(x: 330, y: 277)
        
        addChild(character)
        character.addChild(cameraNode)
    }
    
    // - Character Animation
    func animateCharacter() {
        character.run(SKAction.repeatForever(
            SKAction.animate(with: characterWalkingFrames,
                             timePerFrame: 0.1,
                             resize: false,
                             restore: true)),
                      withKey:"walkingInPlaceCharacter")
    }
    
    // - Move Character
    func moveCharacter(location: CGPoint) {
        // - Moving Logic
        var multiplierForDirection: CGFloat
        let characterSpeed = frame.size.width / 20 //5
        let moveDifference = CGPoint(x: location.x - character.position.x, y: location.y - character.position.y)
        let distanceToMove = sqrt(moveDifference.x * moveDifference.x + moveDifference.y * moveDifference.y)
        let moveDuration = distanceToMove / characterSpeed
        
        // - Inverting Character
        if moveDifference.x < 0 {
            multiplierForDirection = -1.0
        } else {
            multiplierForDirection = 1.0
        }
        character.xScale = abs(character.xScale) * multiplierForDirection
        cameraNode.xScale = abs(cameraNode.xScale) * multiplierForDirection
        
        // - Moving Character
        if character.action(forKey: "walkingInPlaceCharacter") == nil {
            animateCharacter()
        }
        let moveAction = SKAction.move(to: location, duration:(TimeInterval(moveDuration)))
        let doneAction = SKAction.run({ [weak self] in
            self?.characterMoveEnded()
        })
        let moveActionWithDone = SKAction.sequence([moveAction, doneAction])
        character.run(moveActionWithDone, withKey:"characterMoving")
    }
    
    func characterMoveEnded() {
        character.removeAllActions()
    }
    
    // - Elevator building
    func buildElevator() {
        var pieceFrames: [SKTexture] = []
        for i in 0...29 {
            let pieceTextureName = "Elevador_Personagem_\(i)"
            let piece = SKTexture(imageNamed: pieceTextureName)
            pieceFrames.append(piece)
        }
        
        pieceFloatingFrames = pieceFrames
        let firstFrameTexture = pieceFloatingFrames[0]
        piece = SKSpriteNode(texture: firstFrameTexture)
        piece.position = CGPoint(x: 872, y: 565)
        piece.zPosition = -8
        
        addChild(piece)
    }
    // - Elevator animation
    func animateElevator() {
        piece.run(SKAction.animate(with: pieceFloatingFrames,
                                   timePerFrame: 0.15,
                                   resize: false,
                                   restore: false))
    }
    
    // - Cars Builds
    func buildCars() {
        var walkFrames: [SKTexture] = []
        for i in 1...3 {
            let carsTextureName = "cars_\(i)"
            let cars = SKTexture(imageNamed: carsTextureName)
            walkFrames.append(cars)
        }
        carsWalkingFrames = walkFrames
        let firstFrameTexture = carsWalkingFrames[0]
        cars = SKSpriteNode(texture: firstFrameTexture)
        cars.position = CGPoint(x: 645, y: 290)
        
        addChild(cars)
    }
    
    // - Cars Animate
    func animateCars() {
        cars.run(SKAction.repeatForever(
            SKAction.animate(with: carsWalkingFrames,
                             timePerFrame: 0.1,
                             resize: false,
                             restore: true)),
                      withKey:"carsMoving")
    }
    
    // - Cars Builds
    func buildTopCars() {
        var walkFrames: [SKTexture] = []
        for i in 1...3 {
            let carsTextureName = "\(i)"
            let cars = SKTexture(imageNamed: carsTextureName)
            walkFrames.append(cars)
        }
        carsWalkingFrames = walkFrames
        let firstFrameTexture = carsWalkingFrames[0]
        carsTop = SKSpriteNode(texture: firstFrameTexture)
        carsTop.position = CGPoint(x: 850, y: 770)
        
        addChild(carsTop)
    }
    
    // - Cars Animate
    func animateTopCars() {
        carsTop.run(SKAction.repeatForever(
            SKAction.animate(with: carsWalkingFrames,
                             timePerFrame: 0.1,
                             resize: false,
                             restore: true)),
                 withKey:"carsMoving")
    }
    
    
    func moveDialogueBox(position: CGPoint) {
        removeChildren(in: [dialogueBox])
        let positionRelative = CGPoint(x: position.x-1050, y: position.y-1325)
        dialogueBox.zPosition = 11
        
        let moveAction = SKAction.move(to: positionRelative, duration: 2)
        let doneAction = SKAction.run({ [weak self] in
            self?.dialogueBox.removeAllActions()
            self?.dialogueBox.isHidden = false
        })
        let moveActionWithDone = SKAction.sequence([moveAction, doneAction])
        dialogueBox.run(moveActionWithDone, withKey:"boxMoving")
    }
    
    func updateDialogueBox() {
        dialogueBox.removeAllChildren()
        
        if dialogueCount < 11 {
            dialogueCount = dialogueCount+1
        }
        let dialogueImage = SKSpriteNode(imageNamed: "Dialogue\(dialogueCount).png")
        dialogueImage.position = CGPoint(x: dialogueBox.position.x, y: dialogueBox.position.y-815)
        dialogueImage.scale(to: CGSize(width: 1150, height: 400))
        
        switch dialogueCount {
        case 3:
            firstInteraction(location: CGPoint(x: 458.3, y: 332.1))
        case 5:
            play("feedback")
            removeChildren(in: [crossingPiece, cars])
            
            let carsAfter = SKSpriteNode(imageNamed: "cars_1.png")
            carsAfter.position = CGPoint(x: 780, y: 205)
            carsAfter.zPosition = -6
            addChild(carsAfter)
            
            let crossingOnPiece = SKSpriteNode(imageNamed: "Crossing_On.png")
            crossingOnPiece.position = CGPoint(x: 515, y: 420)
            crossingOnPiece.zPosition = -7
            addChild(crossingOnPiece)
            
            
            
            isTouchActivated = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.secondInteraction(location: CGPoint(x: 775.9, y: 512.4))
            }
        case 7:
            isTouchActivated = false
            removeChildren(in: [stairs])
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                self.character.isHidden = true
                self.dialogueBox.isHidden = false
            }
            play("feedback")
            buildElevator()
            animateElevator()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.thirdInteraction(location: CGPoint(x: 933.2, y: 648.1))
            }
        case 9:
            isTouchActivated = false
            play("feedback")
            removeChildren(in: [crossingPiece2, carsTop])
            
            let carsTopAfter = SKSpriteNode(imageNamed: "cars_1.png")
            carsTopAfter.position = CGPoint(x: 1000, y: 680)
            carsTopAfter.zPosition = -10
            addChild(carsTopAfter)
            
            let crossingOnPiece2 = SKSpriteNode(imageNamed: "Crossing_On_2.png")
            crossingOnPiece2.position = CGPoint(x: 714.5, y: 901)
            crossingOnPiece2.zPosition = -11
            addChild(crossingOnPiece2)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.lastInteraction(location: CGPoint(x: 776, y: 881.4))
            }
        case 11:
            isTouchActivated = false
            credits.position = CGPoint(x: dialogueBox.position.x, y: dialogueBox.position.y-900)
            credits.scale(to: CGSize(width: 1150, height: 4370))
            credits.zPosition = 50
            if credits.parent == nil {
                cameraNode.addChild(credits)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                let moveAction = SKAction.move(to: CGPoint(x: self.credits.position.x, y: self.credits.position.y+2000), duration: 8)
                
                self.credits.run(moveAction, withKey:"creditsMoving")
            }
        default: break
        }
        dialogueBox.addChild(dialogueImage)
    }
    
    // - Dialoge Box
    func buildDialogeBox() {
        dialogueBox.fillColor = .white
        
        let dialogueImage = SKSpriteNode(imageNamed: "Dialogue1.png")
        dialogueImage.position = CGPoint(x: dialogueBox.position.x, y: dialogueBox.position.y-815)
        dialogueImage.scale(to: CGSize(width: 1150, height: 400))
        
        cameraNode.addChild(dialogueBox)
        dialogueBox.addChild(dialogueImage)
    }
    

    
    // - Interactions
    func firstInteraction(location: CGPoint) {
        isTouchActivated = false
        moveCharacter(location: CGPoint(x: 337.7, y: 263.1))
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            self.moveCharacter(location: location)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                self.isTouchActivated = true
            }
        }
    }
    func secondInteraction(location: CGPoint) {
        moveCharacter(location: location)
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.9) {
            self.moveCharacter(location: CGPoint(x: 813.7, y: 489.7))
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.isTouchActivated = true
            }
        }
    }
    func thirdInteraction(location: CGPoint) {
        moveCharacter(location: location)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.85) {
            self.character.isHidden = false
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.moveCharacter(location: CGPoint(x: 654.3, y: 812.4))
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) {
                self.isTouchActivated = true
            }
        }
    }
    func lastInteraction(location: CGPoint) {
        moveCharacter(location: location)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.moveCharacter(location: CGPoint(x: 538.5, y: 1018.3))
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                self.moveCharacter(location: CGPoint(x: 887.6, y: 1227.8))
                DispatchQueue.main.asyncAfter(deadline: .now() + 7) {
                    self.isTouchActivated = true
                }
            }
        }
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isTouchActivated {
            for t in touches {
                touchDown(position: t.location(in: self))
            }
        }
    }
    
    func touchDown(position: CGPoint) {
        if isTouchActivated{
            if self.nodes(at: position).contains(dialogueBox) {
                updateDialogueBox()
            }
        }
    }
    
    func play(_ fileName: String) {
        guard let url = Bundle.main.url(forResource: fileName, withExtension: "mp3") else { return }
        do {
            if fileName == "ES_Challenges Ahead - From Now On" {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                try AVAudioSession.sharedInstance().setActive(true)
                player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
                guard let player = player else { return }
                player.numberOfLoops = -1
                player.play()
            } else {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                try AVAudioSession.sharedInstance().setActive(true)
                feedbackPlayer = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
                guard let feedbackPlayer = feedbackPlayer else { return }
                feedbackPlayer.volume = 4
                feedbackPlayer.play()
            }
        } catch let error {
            print(error.localizedDescription)
        }
    }
}
