import UIKit
import SpriteKit

public class GameViewController: UIViewController {
    override public func viewDidLoad() {
        super.viewDidLoad()
        let skView = SKView(frame: CGRect(x: 0, y: 0, width: 1224, height: 1983))
        self.view = skView
        if let view = view as? SKView {
            
            // Creating the scene programmatically
            let scene = GameScene(size: view.bounds.size)
            scene.scaleMode = .aspectFill
            view.ignoresSiblingOrder = true
            view.presentScene(scene)
        }
    }
    override public var prefersStatusBarHidden: Bool {
        return true
    }
}
